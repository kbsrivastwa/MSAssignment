Assumptions

1) I have not used any java based frameworks/webservices/ejbs/j2ee/j2ee design patterns
since there is no explicit requirement for this in the given requirement document

2) I have not checked for any business rules since it is not explicitly defined in the given  requirement document
3) I have assumed the "given any stock price" as 2500 for all stocks


